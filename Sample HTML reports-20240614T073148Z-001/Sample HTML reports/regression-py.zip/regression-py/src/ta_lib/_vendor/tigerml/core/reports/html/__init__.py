from . import table_styles as preset_styles
from .contents import *
from .lib import create_html_report, report_configs
from .Report import HTMLDashboard, HTMLReport
