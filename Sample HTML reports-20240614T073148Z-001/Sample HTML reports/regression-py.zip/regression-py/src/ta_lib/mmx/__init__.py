"""Collection of utilities focused around Marketing Mix Modelling.

This package provides a collection of utilities focused around Market Mix Modelling. The package also provides functions to calculate the attributions of the model.
"""
__version__ = "2.0"
