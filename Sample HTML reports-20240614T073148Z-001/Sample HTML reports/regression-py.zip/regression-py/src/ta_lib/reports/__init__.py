"""Utility functions to create common reports and charts."""
