"""rtm package for quantifying various rtm activities on sales."""
__version__ = "2.0"
