class PipelineError(BaseException):
    """Base class to for exceptions during pipeline run."""

    pass
