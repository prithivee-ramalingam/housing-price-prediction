========
Modeling
========


Approaches
==========

A more detailed description of approaches discussed, approaches that were experimented, pros & cons of each.


Experimentations
================

Describe the high level experiments across approaches, results, comparisons & interpretation.

Interpretations
---------------


Results & comparisons
---------------------


Finalized model
================

Describe the rational for choosing the finalized model, trade offs & future scope of improvement.

