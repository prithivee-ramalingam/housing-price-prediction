==========
Deployment
==========

This can be repeated by models / usecases / pipeline.

Deployment Architecture
=======================

Paths
=====

Inputs
------

Outputs
-------

Pipelines
=========

Code location in git/server paths. Schedules & execution configuration

Logging
=======

Monitoring
==========

Debugging failures
------------------

Interventions
-------------

Configuration Files
===================


Credential Management
=====================