.. Project_X documentation master file, created by
   sphinx-quickstart on Fri Jul  3 12:53:59 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Project_X documentation!
===================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   project_overview
   developer_guide
   api_guide
   user_guide
   best_practices


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
