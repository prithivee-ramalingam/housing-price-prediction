======
ta_lib
======

.. autosummary::
   :toctree: ../_autosummary/
   :template: module.rst
   
   ta_lib.regression.api
   
