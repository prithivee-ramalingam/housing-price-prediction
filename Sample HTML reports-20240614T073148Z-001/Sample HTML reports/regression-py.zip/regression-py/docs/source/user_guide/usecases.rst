========
Tool kit
========

In this section we describe the steps needed for a user to be able to use the tool/dashboard/app end-to-end.

To add: Include step by step information flow, accessing results, callouts for exceptions, troubleshooting, support / help contacts.
